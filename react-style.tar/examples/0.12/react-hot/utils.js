module.exports = `dep ${1}`;
